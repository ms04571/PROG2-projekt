import re
import requests
import json
import numpy as np
import matplotlib.pyplot as plt

FILES=['user_rating,desc','user_rating,asc','relese_date,asc','release_date,desc']
GENRES=['Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime', 'Drama', 'Family', 'Fantasy', 'Film-Noir', 'History', 'Horror', 'Music', 'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Sport', 'Thriller', 'War', 'Western']


def genres(movies):
    """iz slovarja movies oblike {imdb_id: [title, gross, budget ,[genres], run_time]}
       prešteje vse žanre in vrne slovar kjer so ključi žanre, vrednostih pa pogostost
       žanre v procentih
    """
    res={}
    for genre in GENRES:
        res[genre]=0
    for movie in movies.values():
        for genre in movie[3]:
            res[genre]+=1/250*100
    return dict(sorted(res.items()))


def openJSON(file_name):
    """odpre in vrne json datoteko"""
    with open(file_name,'r') as file:
        return json.load(file)
    

def data(movies):
    """prebere vse podatke o filmih in v slovar all_movies doda vsak film
       in mu izračuna profit, razmerje med zaslužkom in proračunom, in
       zaslužek na minuto filma.
       nato vrne še povprečje razmerji zaslužka za vsako žanro
    """
    res={}
    for genre in GENRES: # zgenereramo prazen končni rezultat
        res[genre]=[0,0]
    for naslov,worldwide,budget,genres,time in movies.values():
        if worldwide==None or budget==None: # če teh podatkov ni lahko film kar izpustimo
            continue
        profit=worldwide-budget
        ratio=worldwide/budget
        ppm=profit/time
        all_movies[naslov]=[profit,ratio,ppm]
        for genre in genres:  # seštevamo razmerja in število razmerij
            res[genre][0]+=ratio
            res[genre][1]+=1
            
    for genre,info in res.items():
        try:     # nekatere žanre so lahko prazne in bi prišlo do deljenja z 0
            res[genre]=info[0]/info[1]
            
        except:
            res[genre]=0
            
    return res

all_movies={}

top_rated=openJSON(FILES[0]+'.json')
bottom_rated=openJSON(FILES[1]+'.json')
newest=openJSON(FILES[2]+'.json')
oldest=openJSON(FILES[3]+'.json')



# grafi pogostosti žanr v procentih za vse 4 extreme
top_rated_genres=genres(top_rated)
bottom_rated_genres=genres(bottom_rated)
newest_genres=genres(newest)
oldest_genres=genres(oldest)

fig1,ax=plt.subplots(2,2,figsize=[12,8])

x1=ax[0][0].bar(GENRES,top_rated_genres.values(),0.9,color='blue')
ax[0][0].tick_params(axis='x',rotation=90)
ax[0][0].set_ylim([0,80])
ax[0][0].title.set_text('Top Rated')
ax[0][0].set_ylabel('%')
ax[0][0].bar_label(x1,fontsize=8)

x2=ax[0][1].bar(GENRES,bottom_rated_genres.values(),0.9,color='orange')
ax[0][1].tick_params(axis='x',rotation=90)
ax[0][1].set_ylim([0,80])
ax[0][1].title.set_text('Bottom Rated')
ax[0][1].set_ylabel('%')
ax[0][1].bar_label(x2,fontsize=8)

x3=ax[1][0].bar(GENRES,newest_genres.values(),0.9,color='purple')
ax[1][0].tick_params(axis='x',rotation=90)
ax[1][0].set_ylim([0,80])
ax[1][0].title.set_text('Newest')
ax[1][0].set_ylabel('%')
ax[1][0].bar_label(x3,fontsize=8)

x4=ax[1][1].bar(GENRES,oldest_genres.values(),0.9,color='red')
ax[1][1].tick_params(axis='x',rotation=90)
ax[1][1].set_ylim([0,80])
ax[1][1].title.set_text('Oldest')
ax[1][1].set_ylabel('%')
ax[1][1].bar_label(x4,fontsize=8)

fig1.tight_layout()





# grafi razmerji dobička proti proračunu za vse 4 extreme
top_rated_data=data(top_rated)
bottom_rated_data=data(bottom_rated)
newest_data=data(newest)
oldest_data=data(oldest)

fig2,ax2=plt.subplots(2,2,figsize=[12,8])

x1=ax2[0][0].bar(GENRES,top_rated_data.values(),0.9,color='blue')
ax2[0][0].tick_params(axis='x',rotation=90)
ax2[0][0].title.set_text('Top Rated')
ax2[0][0].set_ylim([0,30])
ax2[0][0].bar_label(x1,fontsize=8,fmt='%.1f')

x2=ax2[0][1].bar(GENRES,bottom_rated_data.values(),0.9,color='orange')
ax2[0][1].tick_params(axis='x',rotation=90)
ax2[0][1].title.set_text('Bottom Rated')
ax2[0][1].set_ylim([0,30])
ax2[0][1].bar_label(x2,fontsize=8,fmt='%.1f')

x3=ax2[1][0].bar(GENRES,newest_data.values(),0.9,color='purple')
ax2[1][0].tick_params(axis='x',rotation=90)
ax2[1][0].title.set_text('Newest')
ax2[1][0].set_ylim([0,30])
ax2[1][0].bar_label(x3,fontsize=8,fmt='%.1f')

x4=ax2[1][1].bar(GENRES,oldest_data.values(),0.9,color='red')
ax2[1][1].tick_params(axis='x',rotation=90)
ax2[1][1].title.set_text('Oldest')
ax2[1][1].set_ylim([0,30])
ax2[1][1].bar_label(x4,fontsize=8,fmt='%.1f')

fig2.tight_layout()







# grafi profita, razmerja in profita na minuto za najboljših in najslabših 10 filmov
fig3,ax3=plt.subplots(2,4,figsize=[15,10])

#top rated
all_movies=dict(sorted(all_movies.items(),key=lambda x:x[1][0],reverse=True))
ax3[0][1].bar(list(all_movies.keys())[:10],np.array(list(all_movies.values()))[:10,0],color='blue')
ax3[0][1].tick_params(axis='x',rotation=90)
ax3[0][1].set_ylabel('$')
ax3[0][1].set_title('Profit',fontsize=15)

all_movies=dict(sorted(all_movies.items(),key=lambda x:x[1][1],reverse=True))
ax3[0][2].bar(list(all_movies.keys())[:10],np.array(list(all_movies.values()))[:10,1],color='red')
ax3[0][2].tick_params(axis='x',rotation=90)
ax3[0][2].set_ylabel('Gross/Budget')
ax3[0][2].set_title('Profit Ratio',fontsize=15)

all_movies=dict(sorted(all_movies.items(),key=lambda x:x[1][2],reverse=True))
ax3[0][3].bar(list(all_movies.keys())[:10],np.array(list(all_movies.values()))[:10,2],color='green')
ax3[0][3].tick_params(axis='x',rotation=90)
ax3[0][3].set_ylabel('$/min')
ax3[0][3].set_title('Profit Per Minute',fontsize=15)

#bottom_rated
all_movies=dict(sorted(all_movies.items(),key=lambda x:x[1][0],reverse=False))
ax3[1][1].bar(list(all_movies.keys())[:10],np.array(list(all_movies.values()))[:10,0],color='blue')
ax3[1][1].tick_params(axis='x',rotation=90)
ax3[1][1].set_ylabel('$')
ax3[1][1].set_title('Profit',fontsize=15)

all_movies=dict(sorted(all_movies.items(),key=lambda x:x[1][1],reverse=False))
ax3[1][2].bar(list(all_movies.keys())[:10],np.array(list(all_movies.values()))[:10,1],color='red')
ax3[1][2].tick_params(axis='x',rotation=90)
ax3[1][2].set_ylabel('Gross/Budget')
ax3[1][2].set_title('Profit Ratio',fontsize=15)

all_movies=dict(sorted(all_movies.items(),key=lambda x:x[1][2],reverse=False))
ax3[1][3].bar(list(all_movies.keys())[:10],np.array(list(all_movies.values()))[:10,2],color='green')
ax3[1][3].tick_params(axis='x',rotation=90)
ax3[1][3].set_ylabel('$/min')
ax3[1][3].set_title('Profit Per Minute',fontsize=15)

#dodaten text
ax3[0][0].annotate('Top 10',(0.25,0.5),size=25)
ax3[0][0].axis('off')
ax3[1][0].annotate('Bottom 10',(0.25,0.5),size=25)
ax3[1][0].axis('off')

fig3.tight_layout(pad=1)


plt.show()
































