import re
import requests
import json
from bs4 import BeautifulSoup

# Iskanje podatkov lahko traja 15-20 min, če ima spremenljivka count vrednost 250, saj mora program
# prebrati 1004 spletnih strani. Podatki o vseh 1000 filmih so že shranjeni v json datotekah.
# Lahko pa se hitreje preveri delovanje programa tako da se count zmanjša na npr. 50 ali manj.
# Seveda bodo zaradi tega lahko tudi drugačni rezultati 
count=250

# S tem se izognemo manj pomembnih/znanih filmov
min_votes=100000


IMDB='https://www.imdb.com/search/title/?title_type=feature&num_votes={:},&count={:}&sort='.format(min_votes,count)
BOXOFFICE='https://www.boxofficemojo.com/title/'

# različne končnice linka za iskanje filmov
#         najboljši rating       najslabši rating        najnovejši          najstarejši
ENDINGS=['user_rating,desc',    'user_rating,asc',   'relese_date,asc',   'release_date,desc']
# za branje strani potrebujemo header ker im stran zaščito proti robotom
HEADER={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',"Accept-Language": "en-US,en;q=0.5"}



def moveisAndIds(ending):
    """sprejeme končnico linka za imdb search in vrne prvih 250 filmov
       in njihov imdb_id oblike "tt123456789", ki je uporaben za vse ostalo isaknje
       podatkov po drugih straneh
       vrne slovar kjer so ključi imdb_id-ji in vrednosti so naslovi filmov
    """
    link=IMDB+ending
    html=requests.get(link,headers=HEADER).text
    soup=BeautifulSoup(html,'html.parser')
    moveis=soup.findAll(class_="ipc-title-link-wrapper")
    id_title={}
    id_re=r'(tt\d+)'
    naslov_re=r'\d\. (.*)</h'
    for movie in moveis:
        movie=str(movie)
        imdb_id=re.search(id_re,movie).group(0)
        naslov=re.search(naslov_re,movie).group(0)[3:-3]
        id_title[imdb_id]=[naslov]
    return id_title
  
def saveJSON(dictionary,file_name):
    """shrani slovar v json datoteko"""
    with open(file_name,'w') as file:
        json.dump(dictionary,file)


def movieInfo(imdb_id):
    """za film z imdb_id-jem oblike "tt123456789" prebere stran boxofficemojo.com
       in shrani podatke o celotnem zaslužku filma, proračunu, vse žanre in dolžino filma v minutah
       vrne seznam oblike [worldwide,budget,[genres],time]
    """
    link=BOXOFFICE+imdb_id+'/'
    html=requests.get(link,headers=HEADER).text
    soup=BeautifulSoup(html,'html.parser')
    
    try: # možno je da stran nima teh podatkov
        denar=soup.findAll(class_="money",limit=3)
        worldwide=int(denar[2].text.replace(',','').replace('$',''))
    except:
        worldwide=None
        
    budget=soup.find(string=re.compile('Budget'))
    if not budget==None: # spet je možno da stran nima teh podatkov
        budget=int(budget.next_element.text.replace(',','').replace('$',''))
        
    genres=soup.find(string=re.compile('Genres')).next_element.text.replace('\n','-').replace(' ','').split('--')
    
    time_text=soup.find(string=re.compile('Running Time')).next_element.text  
    hr_min=re.findall(r'(\d+)',time_text) # čas oblike "x hr yy min"
    if len(hr_min)<2:
        time=int(hr_min[0])*60
    else:
        time=int(hr_min[0])*60+int(hr_min[1])

        
    return [worldwide,budget,genres,time]
    

# za vsako končnico ustvarimo slovar filmov in ga shranimo v .json datoteko
i=1
for ending in ENDINGS:
    moveis=moveisAndIds(ending)
    j=1
    for imdb_id in moveis.keys():
        # izpis za spremljanje postopka in ugotavljanje napak
        print('{:}/4    {:}/250    {:}'.format(i,j,imdb_id)) 
        j+=1
        moveis[imdb_id]+=movieInfo(imdb_id)
    i+=1
    
    saveJSON(moveis,ending+'.json')
























